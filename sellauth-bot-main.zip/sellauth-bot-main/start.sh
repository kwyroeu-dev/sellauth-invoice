#!/bin/bash
echo "Starting SellAuth Bot..."
node src/index.js

npm start 